const mongoose = require('mongoose');

const customerSchema = new mongoose.Schema({
  customerId: { type: String, required: true, unique: true },
  customerName: String,
  billingMonth: String,
  amount: Number,
  dueDate: String,
  status: String,
},{collection: 'customer'});

module.exports = mongoose.model('Customer', customerSchema);
