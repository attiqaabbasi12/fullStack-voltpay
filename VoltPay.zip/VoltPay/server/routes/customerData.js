const express = require('express');
const router = express.Router();
const mongoose = require('mongoose');
const Customer = require('../models/customer');

router.get('/customer/:customerId', async (req, res) => {
  try {
    const customerId = req.params.customerId.toUpperCase();
    const customer = await Customer.findOne({ customerId });
    if (!customer) {
      return res.status(404).json({ message: 'Record not found' });
    }
    res.json(customer);
  } catch (err) {
    console.error('Error fetching customer data:', err);
    res.status(500).json({ message: 'Server error' });
  }
});

module.exports = router;
