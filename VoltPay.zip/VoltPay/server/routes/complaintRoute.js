const express = require('express');
const router = express.Router();
const Complaint = require('../models/complaint');

router.post('/submit', async (req, res) => {
  try {
    const complaint = new Complaint(req.body);
    await complaint.save();
    res.status(201).json({ message: 'Complaint submitted successfully' });
  } catch (err) {
    res.status(500).json({ message: 'Error submitting complaint', error: err });
  }
});

module.exports = router;
