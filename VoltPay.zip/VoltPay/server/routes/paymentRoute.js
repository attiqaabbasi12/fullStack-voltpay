const express = require('express');
const router = express.Router();
const Customer = require('../models/customer');

// Get payment status
router.get('/payment-status/:customerId', async (req, res) => {
  try {
    const { customerId } = req.params;
    const customer = await Customer.findOne({ customerId });

    if (!customer) {
      return res.status(404).json({ message: 'Customer not found' });
    }

    return res.json({ status: customer.status });
  } catch (error) {
    res.status(500).json({ error: 'Server error' });
  }
});

// Process payment (simulate)
router.post('/process-payment', async (req, res) => {
  try {
    const { customerId, amount, paymentMethod, accountNumber } = req.body;

    const customer = await Customer.findOne({ customerId });
    if (!customer) {
      return res.status(404).json({ message: 'Customer not found' });
    }

    // Simulate logging payment info
    console.log(`Payment processed for ${customerId} using ${paymentMethod}.`);

    return res.json({ message: 'Payment processed' });
  } catch (error) {
    res.status(500).json({ error: 'Payment processing failed' });
  }
});

// Update payment status
router.put('/update-status/:customerId', async (req, res) => {
  try {
    const { customerId } = req.params;
    const { status } = req.body;

    const updated = await Customer.findOneAndUpdate(
      { customerId },
      { status },
      { new: true }
    );

    if (!updated) {
      return res.status(404).json({ message: 'Customer not found' });
    }

    res.json({ message: `Status updated to ${status}` });
  } catch (error) {
    res.status(500).json({ error: 'Update failed' });
  }
});

module.exports = router;
