import React from 'react'
import Navbar from '../components/Navbar'
import CustomerForm from '../components/CustomerForm'

const Dashboard = () => {
  return (
    <>
        <Navbar />
        <CustomerForm />
    </>
  )
}

export default Dashboard