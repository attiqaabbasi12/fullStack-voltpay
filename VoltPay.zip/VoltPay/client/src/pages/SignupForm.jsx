import React, { useState } from 'react';
import { useNavigate, Link } from 'react-router-dom';

function SignupForm() {
  const [formData, setFormData] = useState({
    name: '',
    email: '',
    password: ''
  });

  const handleChange = (e) => {
    setFormData({
      ...formData,
      [e.target.name]: e.target.value
    });
  };

  const navigate = useNavigate();

  const handleSubmit = async (e) => {
    e.preventDefault();

    const response = await fetch('http://localhost:5000/api/signup', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json'
      },
      body: JSON.stringify(formData)
    });

    const data = await response.json();
    alert(data.message);

    if (response.ok) {
      navigate('/login');
      // Reset form fields
      setFormData({
        name: '',
        email: '',
        password: ''
      });
    }
  };

  return (
    <div className="w-full h-screen flex flex-col items-center justify-center bg-red-100">
      {/* Signup Form */}
      <div className="w-[400px] h-[420px] bg-white border border-gray-200 rounded-xl flex flex-col items-center justify-center">
        <form className="w-[320px]" onSubmit={handleSubmit}>
          <h1 className="text-center text-red-600 font-semibold text-3xl mb-8">Sign Up</h1>

          <div className="relative mb-5">
            <i className="fa-solid fa-user absolute top-1/2 left-4 -translate-y-1/2 text-gray-600"></i>
            <input
              type="text"
              name="name"
              placeholder="Name"
              required
              value={formData.name}
              onChange={handleChange}
              className="w-full pl-10 pr-4 py-3 border-2 border-gray-300 rounded-md bg-gray-100 focus:outline-none focus:border-red-600 focus:bg-white"
            />
          </div>

          <div className="relative mb-5">
            <i className="fas fa-envelope absolute top-1/2 left-4 -translate-y-1/2 text-gray-600"></i>
            <input
              type="email"
              name="email"
              placeholder="Email"
              required
              value={formData.email}
              onChange={handleChange}
              className="w-full pl-10 pr-4 py-3 border-2 border-gray-300 rounded-md bg-gray-100 focus:outline-none focus:border-red-600 focus:bg-white"
            />
          </div>

          <div className="relative mb-5">
            <i className="fas fa-lock absolute top-1/2 left-4 -translate-y-1/2 text-gray-600"></i>
            <input
              type="password"
              name="password"
              placeholder="Password"
              required
              value={formData.password}
              onChange={handleChange}
              className="w-full pl-10 pr-4 py-3 border-2 border-gray-300 rounded-md bg-gray-100 focus:outline-none focus:border-red-600 focus:bg-white"
            />
          </div>

          <div className="mb-4">
            <button
              type="submit"
              className="w-full py-3 bg-red-600 text-white rounded-md font-medium hover:bg-red-700 transition"
            >
              Register
            </button>
          </div>
        </form>
        <div>
        <span>Already Registered? <Link to="/login" className="text-red-600 underline">Login</Link></span>
      </div>
      </div>
    </div>
  );
}

export default SignupForm;
