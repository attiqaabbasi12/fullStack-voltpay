import React from 'react'
import PaymentForm from '../components/PaymentForm'
import Navbar from '../components/Navbar'

const Payment = () => {
  return (
    <>
        <Navbar />
        <PaymentForm />
    </>
  )
}

export default Payment