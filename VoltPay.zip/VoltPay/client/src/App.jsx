import { BrowserRouter, Routes, Route } from "react-router-dom";
import Signup from "./pages/SignupForm";
import './index.css'; 
import LoginForm from "./pages/LoginForm";
import Dashboard from "./pages/Dashboard";
import Home from "./pages/Home";
import Payment from "./pages/Payment";
import Complaint from "./pages/ComplaintForm";

function App() {
  return (
    <BrowserRouter>
      <Routes>
        <Route path="/" element={<Home />} /> 
        <Route path="/signup" element={<Signup />} />
        <Route path="/login" element={<LoginForm />} />
        <Route path="/dashboard" element={<Dashboard />} />
        <Route path="/payment" element={<Payment />} />
        <Route path="/complaint" element={<Complaint />} />
      </Routes>
    </BrowserRouter>
  );
}

export default App;
