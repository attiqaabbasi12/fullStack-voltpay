import React from 'react';
import { Link } from 'react-router-dom';

const Navbar = () => {
  return (
    <header className="flex-col text-center items-center px-10 py-4 bg-red-600 text-white shadow-md">
      <h1 className="text-3xl font-bold mb-4 ">VoltPay</h1>
      <nav>
        <ul className="flex gap-6 text-lg font-medium justify-center">
          <li><Link to="/dashboard" className="hover:underline">Home</Link></li>
          <li><Link to="/payment" className="hover:underline">Payment</Link></li>
          <li>
            <a
              href="/complaint"
              target="_blank"
              rel="noopener noreferrer"
              className="hover:underline"
            >
              Complaint
            </a>
          </li>
        </ul>
      </nav>
    </header>
  );
};

export default Navbar;
