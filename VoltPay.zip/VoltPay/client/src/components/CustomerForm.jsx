import React, { useState } from 'react';
import { Link } from 'react-router-dom'; 

const CustomerForm = () => {
  const [customerId, setCustomerId] = useState('');
  const [billData, setBillData] = useState(null);
  const [error, setError] = useState('');

  const fetchBillData = async () => {
    setError('');
    setBillData(null);

    try {
      const response = await fetch(`http://localhost:5000/api/customer/${customerId.trim().toUpperCase()}`);
      if (response.ok) {
        const data = await response.json();
        setBillData(data);
      } else if (response.status === 404) {
        setError('Record not found.');
      } else {
        setError('Failed to fetch data.');
      }
    } catch (err) {
      setError('Server error. Please try again later.');
    }
  };

  return (
    <div className="inquiry border rounded-lg p-6 shadow-5xl max-w-md mx-auto mt-10">
      <h2 className="text-center font-bold text-xl">Inquire Bill</h2>
      <form onSubmit={(e) => e.preventDefault()}>
        <div className="input-field mt-5 flex flex-col mb-4">
          <label htmlFor="customer-id" className="mb-1 font-semibold">
            Customer ID:
          </label>
          <input
            type="text"
            id="customer-id"
            value={customerId}
            onChange={(e) => setCustomerId(e.target.value)}
            className="p-2 rounded-md border-2 border-gray-700 focus:outline-none focus:border-red-500"
            placeholder="Enter customer ID (CUST001)"
            required
          />
        </div>
        <input
          type="button"
          onClick={fetchBillData}
          value="Inquire"
          className="w-full p-2 text-white bg-red-600 rounded-md cursor-pointer text-lg hover:bg-red-700 transition"
        />
      </form>

      {error && <p className="text-red-600 mt-3">{error}</p>}

      {billData && (
        <div className="bill-data mt-7 space-y-1 text-gray-700">
          <p><strong>Customer:</strong> {billData.customerName}</p>
          <p><strong>Billing Month:</strong> {billData.billingMonth}</p>
          <p><strong>Amount:</strong> Rs. {billData.amount}</p>
          <p><strong>Due Date:</strong> {billData.dueDate}</p>
          <p><strong>Status:</strong> {billData.status}</p>
          <div className="mt-3 bg-red-600 text-center p-2 rounded-md cursor-pointer hover:bg-red-700 transition">
            <Link to="/payment" className="text-white no-underline">Pay</Link>
          </div>
        </div>
      )}
    </div>
  );
};

export default CustomerForm;
