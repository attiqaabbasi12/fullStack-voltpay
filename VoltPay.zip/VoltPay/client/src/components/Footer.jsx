import React from 'react';

const Footer = () => {
  return (
    <footer className="mt-[100px] text-white">
      <section className="bg-black flex justify-between px-[150px] py-[50px]" id="about-us">
        <div className="w-[40%] text-justify">
          <h3 className="text-[30px] text-red-600">About Us</h3>
          <p>
            This Electricity Bill Payment Website is designed to provide users with a convenient and secure platform to pay their electricity bills online.
            It allows users to check their bill details, make payments easily, and track their payment history.
            The purpose of this website is to save users' time and effort by providing a fast and hassle-free online billing system.
          </p>
        </div>
        <div>
          <h3 className="text-[30px] text-red-600">Contact Us</h3>
          <ul className="list-none">
            <li className="cursor-pointer mt-2">
              <i className="fa-brands fa-instagram text-red-600"></i>
              <span className="ml-2">voltpay</span>
            </li>
            <li className="cursor-pointer mt-2">
              <i className="fa-solid fa-phone text-red-600"></i>
              <span className="ml-2">+9231 2312345</span>
            </li>
            <li className="cursor-pointer mt-2">
              <i className="fa-solid fa-envelope text-red-600"></i>
              <span className="ml-2">voltpay@gmail.com</span>
            </li>
          </ul>
        </div>
      </section>
      <div className="bg-black bg-opacity-50 text-center py-3">
        &copy; 2025 VoltPay. All rights reserved.
      </div>
    </footer>
  );
};

export default Footer;
