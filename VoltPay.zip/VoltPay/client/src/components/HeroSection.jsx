import React from 'react';
import { Link } from 'react-router-dom'; 
import hero from '../assets/images/hero.jpg';

const HeroSection = () => {
  return (
    <section className="flex justify-around px-[70px] mt-[60px]">
      <div className="w-[42%]">
        <h1 className="text-[65px] leading-[70px] font-bold text-black">
          Your <span className="text-red-600">Electricity</span> Bills, Paid in a Flash!
        </h1>
        <p className="text-[20px] mt-[10px] mb-[20px]">
          Fast, secure, and hassle-free bill payments at your fingertips. Say goodbye to long queues—manage and pay your bills with ease.
        </p>
        <Link
          to="/login"
          className="bg-red-600 text-white px-5 py-2 font-bold rounded-lg text-[17px] hover:bg-red-500 inline-block"
        >
          Pay Now
        </Link>
      </div>
      <div
        className="w-[45%] h-[460px] rounded-[30px] bg-center bg-cover bg-no-repeat"
        style={{ backgroundImage: `url(${hero})` }}
      ></div>
    </section>
  );
};

export default HeroSection;
