import React, { useState } from 'react';
import axios from 'axios';

export default function PaymentForm() {
  const [formData, setFormData] = useState({
    customerId: '',       
    amount: '',
    paymentMethod: '',
    accountNumber: '',
  });

  const [loading, setLoading] = useState(false);
  const [paymentSuccess, setPaymentSuccess] = useState(false);
  const [alreadyPaid, setAlreadyPaid] = useState(false);

  const handleChange = (e) => {
    setFormData({ ...formData, [e.target.id]: e.target.value });
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    setLoading(true);
    setAlreadyPaid(false);
    setPaymentSuccess(false);

    try {
      // 1. Check payment status
      const statusRes = await axios.get(`http://localhost:5000/api/payment-status/${formData.customerId}`);

      if (statusRes.data.status === 'Paid') {
        setAlreadyPaid(true);
        setLoading(false);
        return;
      }

      // 2. Proceed with payment
      await axios.post('http://localhost:5000/api/process-payment', {
        customerId: formData.customerId,
        amount: formData.amount,
        paymentMethod: formData.paymentMethod,
        accountNumber: formData.accountNumber,
      });

      // 3. Update backend to Paid
      await axios.put(`http://localhost:5000/api/update-status/${formData.customerId}`, {
        status: 'Paid',
      });

      setPaymentSuccess(true);
      setFormData({
        customerId: '',
        amount: '',
        paymentMethod: '',
        accountNumber: '',
      });
    } catch (error) {
      if (error.response && error.response.status === 404) {
        alert('Customer ID not found. Please check and try again.');
      } else {
        console.error('Payment error:', error);
        alert('An error occurred while processing the payment.');
      }
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="payment-form mt-8 bg-white p-8 rounded-2xl shadow-md w-96 mx-auto">
      <h2 className="text-center text-2xl font-semibold">Payment Form</h2>
      <form id="paymentForm" onSubmit={handleSubmit}>
        <input
          type="text"
          id="customerId"   // match state key exactly
          placeholder="Enter Customer ID"
          value={formData.customerId}
          onChange={handleChange}
          required
          className="w-full mt-4 p-2 border rounded-md border-gray-400"
        />
        <input
          type="number"
          id="amount"
          placeholder="Enter Amount"
          value={formData.amount}
          onChange={handleChange}
          required
          className="w-full mt-4 p-2 border rounded-md border-gray-400"
        />
        <select
          id="paymentMethod"
          value={formData.paymentMethod}
          onChange={handleChange}
          required
          className="w-full mt-4 p-2 border rounded-md border-gray-400"
        >
          <option value="">Select Payment Method</option>
          <option value="EasyPaisa">EasyPaisa</option>
          <option value="JazzCash">JazzCash</option>
          <option value="BankTransfer">Bank Transfer</option>
        </select>
        <input
          type="text"
          id="accountNumber"
          placeholder="Enter Account Number"
          value={formData.accountNumber}
          onChange={handleChange}
          required
          className="w-full mt-4 p-2 border rounded-md border-gray-400"
        />
        <button
          type="submit"
          disabled={loading}
          className="w-full mt-6 p-2 bg-red-600 text-white rounded-md cursor-pointer"
        >
          Proceed Now
        </button>

        {loading && (
          <div className="loader mt-4 mx-auto border-t-4 border-t-red-600 border-4 border-gray-300 rounded-full w-8 h-8 animate-spin"></div>
        )}
        {alreadyPaid && (
          <div className="mt-4 text-yellow-600 font-semibold text-center">
            This customer has already paid.
          </div>
        )}
        {paymentSuccess && (
          <div className="success-message mt-4 text-green-600 font-bold text-center">
            Payment Successful!
          </div>
        )}
      </form>
    </div>
  );
}
