import React from 'react';
import { Link } from 'react-router-dom';

const Header = () => {
  return (
    <header className="flex justify-between items-center px-[70px] py-5">
      <div className="text-[35px] font-bold">
        <span className="text-red-600">Volt</span>Pay
      </div>
      <nav>
        <ul className="flex items-center list-none">
          <li className="ml-10 font-bold text-black hover:text-red-600">
            <Link to="/">Home</Link>
          </li>
          <li className="ml-10 font-bold text-black hover:text-red-600">
            <Link to="/#features">Features</Link>
          </li>
          <li className="ml-10 font-bold text-black hover:text-red-600">
            <Link to="/#about-us">About Us</Link>
          </li>
          <li className="ml-10">
            <Link
              to="signup"
              className="bg-red-600 text-white px-4 py-2 text-[16px] font-bold rounded-full hover:bg-red-500"
            >
            SignUp
            </Link>
          </li>
        </ul>
      </nav>
    </header>
  );
};

export default Header;
