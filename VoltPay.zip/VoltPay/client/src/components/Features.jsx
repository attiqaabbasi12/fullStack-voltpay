import React from 'react';

const features = [
  {
    title: 'Secure Payments',
    description: 'Provides a safe and secure online payment system to protect user data during bill transactions.',
  },
  {
    title: 'Transaction History',
    description: 'Maintains a record of all previous payments, helping users track their bill payment history easily.',
  },
  {
    title: 'Inquire Bill',
    description: 'Allows users to check their current electricity bill details instantly by entering their customer ID.',
  },
  {
    title: 'Due Alerts',
    description: 'Sends a notification to users when the bill payment due date is near to avoid late payment issues.',
  },
];

const Features = () => {
  return (
    <section className="mt-10" id="features">
      <h2 className="text-center text-[45px] font-bold">Features</h2>
      <div className="flex flex-wrap justify-center gap-10 mt-12 px-[100px]">
        {features.map((feature, index) => (
          <div
            key={index}
            className="w-[270px] h-[130px] p-4 rounded-[20px] text-center bg-gray-300 shadow-lg relative cursor-pointer hover:-translate-y-1 transition"
          >
            <h3 className="text-red-700 mb-1 font-bold">{feature.title}</h3>
            <p className="text-sm">{feature.description}</p>
          </div>
        ))}
      </div>
    </section>
  );
};

export default Features;
